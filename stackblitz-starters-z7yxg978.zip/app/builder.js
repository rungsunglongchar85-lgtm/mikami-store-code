const fs = require('fs')
const path = require('path')

function write(file, content){
  fs.mkdirSync(path.dirname(file), { recursive:true })
  fs.writeFileSync(file, content)
}

/* ================= ROOT ================= */

write('package.json', JSON.stringify({
  name: "mikami-store",
  version: "1.0.0",
  dependencies: {
    "@supabase/supabase-js": "^2.0.0",
    "jsonwebtoken": "^9.0.0"
  }
}, null, 2))

/* ================= LIB ================= */

write('lib/supabase.js', `
import { createClient } from '@supabase/supabase-js'
export const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
)
`)

write('lib/middleware.js', `
import jwt from 'jsonwebtoken'

export function verifyToken(req){
  try{
    const auth = req.headers.authorization
    if(!auth) return null
    return jwt.verify(auth.split(' ')[1], process.env.JWT_SECRET)
  }catch{
    return null
  }
}

export function requireAdmin(req){
  const user = verifyToken(req)
  if(!user || user.role!=='admin') return null
  return user
}
`)

/* ================= AUTH ================= */

write('api/auth.js', `
import jwt from 'jsonwebtoken'

export default function handler(req,res){
  const { email,password } = req.body

  if(email==='admin@test.com' && password==='123456'){
    const token = jwt.sign(
      { id:1, role:'admin' },
      process.env.JWT_SECRET,
      { expiresIn:'7d' }
    )
    return res.json({ token })
  }

  res.status(401).json({ error:'Invalid login' })
}
`)

/* ================= WALLET ================= */

write('api/wallet.js', `
import { supabase } from '../lib/supabase'
import { verifyToken } from '../lib/middleware'

export default async function handler(req,res){
  const user = verifyToken(req)
  if(!user) return res.status(401).json({error:'Unauthorized'})

  const { data } = await supabase
    .from('wallet')
    .select('*')
    .eq('user_id', user.id)
    .single()

  res.json(data)
}
`)

/* ================= ORDERS ================= */

write('api/orders.js', `
import { supabase } from '../lib/supabase'
import { verifyToken } from '../lib/middleware'

export default async function handler(req,res){
  const user = verifyToken(req)
  if(!user) return res.status(401).json({error:'Unauthorized'})

  if(req.method==='POST'){
    const { product,player_id } = req.body

    const { data:prod } = await supabase
      .from('products')
      .select('*')
      .eq('name', product)
      .single()

    const amount = prod.price

    const { data:wallet } = await supabase
      .from('wallet')
      .select('*')
      .eq('user_id', user.id)
      .single()

    if((wallet?.balance||0) < amount){
      return res.json({error:'Insufficient'})
    }

    await supabase.from('wallet')
      .update({ balance: wallet.balance - amount })
      .eq('user_id', user.id)

    await supabase.from('orders').insert({
      user_id:user.id,
      product,
      player_id,
      amount,
      status:'processing'
    })

    res.json({ success:true })
  }

  if(req.method==='GET'){
    const { data } = await supabase.from('orders').select('*')
    res.json(data)
  }
}
`)

/* ================= PRODUCTS ================= */

write('api/products.js', `
import { supabase } from '../lib/supabase'
import { verifyToken } from '../lib/middleware'

export default async function handler(req,res){

  if(req.method==='GET'){
    const { data } = await supabase.from('products').select('*')
    return res.json(data)
  }

  const user = verifyToken(req)
  if(!user) return res.status(401).json({error:'Unauthorized'})

  if(req.method==='POST'){
    const { name,price } = req.body
    await supabase.from('products').insert({ name,price })
    return res.json({success:true})
  }
}
`)

/* ================= PAYMENTS ================= */

write('api/payments.js', `
import { supabase } from '../lib/supabase'

export default async function handler(req,res){
  const { data } = await supabase.from('payments').select('*')
  res.json(data)
}
`)

write('api/approve.js', `
import { supabase } from '../lib/supabase'

export default async function handler(req,res){

  const { id,user,amount } = req.body

  await supabase.from('payments')
    .update({ status:'approved' })
    .eq('id',id)

  const { data:wallet } = await supabase
    .from('wallet')
    .select('*')
    .eq('user_id',user)
    .single()

  await supabase.from('wallet')
    .update({ balance:(wallet?.balance||0)+amount })
    .eq('user_id',user)

  res.json({success:true})
}
`)

/* ================= PUBLIC UI ================= */

write('public/user.html', `
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-black text-white p-4">

<h1 class="text-xl mb-4">MIKAMI STORE</h1>

<div id="products"></div>

<script>

function load(){
fetch('/api/products')
.then(r=>r.json())
.then(data=>{
let html=''
data.forEach(p=>{
html+=\`
<div onclick="buy('\${p.name}')" 
class="bg-gray-800 p-3 mb-2 rounded">
\${p.name} - ₹\${p.price}
</div>\`
})
document.getElementById('products').innerHTML = html
})
}

function buy(name){
fetch('/api/orders',{
method:'POST',
headers:{
'Content-Type':'application/json',
'Authorization':'Bearer '+localStorage.token
},
body: JSON.stringify({
product:name,
player_id:'123'
})
})
.then(r=>r.json())
.then(r=>alert(r.success?'Order Done':r.error))
}

load()
</script>

</body>
</html>
`)

write('public/admin.html', `
<!DOCTYPE html>
<html>
<body style="background:#020617;color:white;padding:20px">

<h1>MIKAMI ADMIN</h1>

<button onclick="orders()">Orders</button>
<button onclick="payments()">Payments</button>

<div id="data"></div>

<script>

function orders(){
fetch('/api/orders',{
headers:{'Authorization':'Bearer '+localStorage.token}
})
.then(r=>r.json())
.then(d=>data.innerHTML = JSON.stringify(d,null,2))
}

function payments(){
fetch('/api/payments')
.then(r=>r.json())
.then(d=>data.innerHTML = JSON.stringify(d,null,2))
}

</script>

</body>
</html>
`)

console.log("🔥 FULL MIKAMI STORE GENERATED") 
node builder.js